"""Copyright(c) 2023 lyuwenyu. All Rights Reserved.
"""

import torch
import torchvision


class VOCEvaluator(object):
    def __init__(self) -> None:
        pass