"""Copyright(c) 2023 lyuwenyu. All Rights Reserved.
"""


# please reference: https://github.com/guojin-yan/RT-DETR-OpenVINO