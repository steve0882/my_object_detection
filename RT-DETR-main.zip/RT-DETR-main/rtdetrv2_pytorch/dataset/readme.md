

```
# configs/dataset/xxx.yml
ln -s /path/to/dataset/ ./dataset/dataset_name
```
