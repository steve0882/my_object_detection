---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: lyuwenyu

---

**Star RTDETR**
请先在RTDETR主页点击**star**以支持本项目
Star RTDETR to help more people discover this project. 

---

**Describe the bug**
A clear and concise description of what the bug is. 
If applicable, add screenshots to help explain your problem. 

**To Reproduce**
Steps to reproduce the behavior.
