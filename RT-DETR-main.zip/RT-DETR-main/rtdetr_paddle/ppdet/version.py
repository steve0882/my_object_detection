# THIS FILE IS GENERATED FROM PADDLEPADDLE SETUP.PY
#
full_version    = '2.4.0'
commit          = '87ed5ba91eaeb332e8e5c3f4e7d5b1d765c75644'
